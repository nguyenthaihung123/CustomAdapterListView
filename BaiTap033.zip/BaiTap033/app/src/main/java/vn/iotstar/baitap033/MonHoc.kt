package vn.iotstar.baitap033

data class MonHoc(
    val name: String,
    val desc: String,
    val pic: Int
)