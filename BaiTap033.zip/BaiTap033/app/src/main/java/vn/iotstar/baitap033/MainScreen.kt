package vn.iotstar.baitap033

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MainScreen() {
    val context = LocalContext.current
    var nameInput by remember { mutableStateOf("") }
    var selectedIndex by remember { mutableStateOf(-1) }
    val monHocList = remember {
        mutableStateListOf(
            MonHoc("Java", "Java 1", R.drawable.java),
            MonHoc("C#", "C# 1", R.drawable.c),
            MonHoc("PHP", "PHP 1", R.drawable.php),
            MonHoc("Kotlin", "Kotlin 1", R.drawable.kotlin),
            MonHoc("Dart", "Dart 1", R.drawable.dart)
        )
    }
    Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
        Text(
            text = "ListView",
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF6200EE))
                .padding(15.dp),
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Thêm môn học:", fontSize = 18.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = nameInput,
                onValueChange = { nameInput = it },
                label = { Text("Nhập tên môn học") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        if (nameInput.isNotEmpty()) {
                            monHocList.add(
                                MonHoc(
                                    nameInput,
                                    "Mô tả mới",
                                    getDrawableForName(nameInput)
                                )
                            )
                            nameInput = ""
                            selectedIndex = -1
                            Toast.makeText(context, "Đã thêm mới", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f).padding(end = 8.dp)
                ) {
                    Text("THÊM")
                }
                Button(
                    onClick = {
                        if (selectedIndex != -1 && nameInput.isNotEmpty()) {
                            val oldItem = monHocList[selectedIndex]
                            monHocList[selectedIndex] = oldItem.copy(name = nameInput)
                            nameInput = ""
                            selectedIndex = -1
                            Toast.makeText(context, "Đã cập nhật", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f).padding(start = 8.dp)
                ) {
                    Text("CẬP NHẬT")
                }
            }
        }
        Divider()
        LazyColumn {
            itemsIndexed(monHocList) { index, item ->
                MonHocItem(
                    monHoc = item,
                    isSelected = index == selectedIndex,
                    onClick = {
                        nameInput = item.name
                        selectedIndex = index
                    }
                )
                Divider(color = Color.LightGray, thickness = 0.5.dp)
            }
        }
    }
}

fun getDrawableForName(name: String): Int {
    return when (name.trim().lowercase()) {

        "java" -> R.drawable.java
        "c#" -> R.drawable.c
        "c" -> R.drawable.c
        "php" -> R.drawable.php
        "kotlin" -> R.drawable.kotlin
        "dart" -> R.drawable.dart

        else -> R.drawable.ngoaile
    }
}
